package uduria.connected_cars_uduria

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
