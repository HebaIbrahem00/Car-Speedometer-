import 'package:flutter/material.dart';
import 'dart:math' show cos, sqrt, asin;
import 'package:segment_display/segment_display.dart' ;

void main() {
  runApp(
      MaterialApp(
      home:CarSpeed(),
          theme: ThemeData(
              textTheme: TextTheme(
                  bodyText1:TextStyle(fontSize: 30,fontWeight: FontWeight.bold) ,
                  bodyText2: TextStyle(fontSize: 40,fontWeight: FontWeight.bold,color: Colors.green))),

      ));


}


// ignore: must_be_immutable

class CarSpeed extends StatefulWidget {
  @override
  _State createState() => _State();
}

class _State extends State<CarSpeed> { //state class that we make an object from it

  int currentspeed =0;
  int time10_30 =0;
  int time30_10 =0;

  @override
  Widget build(BuildContext context) { //context is the data changes
    return  Scaffold(
      appBar: AppBar(title: Text("Car Speedometer" ), centerTitle: true,backgroundColor:Colors.black,),
    body: Column(


    mainAxisAlignment: MainAxisAlignment.spaceBetween,

    children: [
   Center(child: Column( children: <Widget>[Text("Current Speed" ,style: Theme.of(context).textTheme.bodyText1),SevenSegmentDisplay(value: '$currentspeed',size: 8,backgroundColor: Colors.white,segmentStyle: HexSegmentStyle(enabledColor: Colors.green,disabledColor: Colors.white)),Text("Kmh",style: Theme.of(context).textTheme.bodyText1)])) ,
    Column(children: <Widget>[Text("From 10 to 30 ",style: Theme.of(context).textTheme.bodyText1) , SevenSegmentDisplay(value:"$time10_30",size: 8,backgroundColor: Colors.white,segmentStyle: HexSegmentStyle(enabledColor: Colors.green,disabledColor: Colors.white),),Text("Seconds",style: Theme.of(context).textTheme.bodyText1)]),
    Column(children: <Widget>[Text("From 30 to 10 ",style:Theme.of(context).textTheme.bodyText1) , SevenSegmentDisplay(value: "$time30_10",size:8,backgroundColor: Colors.white,segmentStyle: HexSegmentStyle(enabledColor: Colors.green,disabledColor: Colors.white)),Text("Seconds",style: Theme.of(context).textTheme.bodyText1)])]),
    );}

  double calculateDistance(lat1, lon1, lat2, lon2){
    double distance ;
    var p = 0.017453292519943295;
    var c = cos;
    var a = 0.5 - c((lat2 - lat1) * p)/2 +
        c(lat1 * p) * c(lat2 * p) *
            (1 - c((lon2 - lon1) * p))/2;
     return  distance= 12742 * asin(sqrt(a));

}

void calculateSpeed(){


  }
}



/*
class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      appBar: AppBar(
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(widget.title),
      ),
      body: Center(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.
        child: Column(
          // Column is also a layout widget. It takes a list of children and
          // arranges them vertically. By default, it sizes itself to fit its
          // children horizontally, and tries to be as tall as its parent.
          //
          // Invoke "debug painting" (press "p" in the console, choose the
          // "Toggle Debug Paint" action from the Flutter Inspector in Android
          // Studio, or the "Toggle Debug Paint" command in Visual Studio Code)
          // to see the wireframe for each widget.
          //
          // Column has various properties to control how it sizes itself and
          // how it positions its children. Here we use mainAxisAlignment to
          // center the children vertically; the main axis here is the vertical
          // axis because Columns are vertical (the cross axis would be
          // horizontal).
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'You have pushed the button this many times:',
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headline4,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
*/

/*class CarSpeed extends StatefulWidget
{

}*/
/*
class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
        // This makes the visual density adapt to the platform that you run
        // the app on. For desktop platforms, the controls will be smaller and
        // closer together (more dense) than on mobile platforms.
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}*/